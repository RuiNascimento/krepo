# script.kbuilds.installer
Private Kodi build installer/updater<br>

The main functionality is working.  There are some features that still need to be completed.<br>

